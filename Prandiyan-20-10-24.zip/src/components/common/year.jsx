const year = "2024-25";
export default year;
