export const BaseUrl = "https://pranidaya.online/public/api";
